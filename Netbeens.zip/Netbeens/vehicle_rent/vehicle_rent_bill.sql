-- MySQL dump 10.13  Distrib 8.0.14, for Win64 (x86_64)
--
-- Host: localhost    Database: vehicle_rent
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bill` (
  `bill_no` varchar(4) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `booking_id` varchar(7) NOT NULL,
  `toatal_amount` decimal(10,0) NOT NULL,
  `driver_id` varchar(10) NOT NULL,
  `customer_id` varchar(7) NOT NULL,
  `take_date` date NOT NULL,
  `retunt_date` date NOT NULL,
  `booking_to` varchar(45) NOT NULL,
  `booking_from` varchar(45) NOT NULL,
  `package` varchar(17) NOT NULL,
  PRIMARY KEY (`bill_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES ('B1','2019-11-04','02:56:58','B1002',2000,'SelfDrive','C1008','2019-11-04','2019-11-14','vavuniya','jaffna','KM_Package'),('B2','2019-11-04','02:56:58','B1002',3000,'SelfDrive','C1008','2019-11-04','2019-11-14','vavuniya','jaffna','KM_Package'),('B3','2019-11-06','12:38:40','B1004',280,'SelfDrive','C1004','2019-11-06','2019-11-07','vavuniya','jaffna','KM_Package'),('B4','2019-11-06','12:39:52','B1004',280,'SelfDrive','C1004','2019-11-06','2019-11-07','vavuniya','jaffna','KM_Package'),('B5','2019-11-06','12:41:18','B1004',280,'SelfDrive','C1004','2019-11-06','2019-11-07','vavuniya','jaffna','KM_Package');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-08 10:05:44
