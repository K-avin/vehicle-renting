
package vehicle_renting;

public class paymenttable {
    private String  BookingID,DriverID,CustomerID,packages,day,km,Driversalary,TotalAmount;
    String[] row;
     public paymenttable(String BookingID,String DriverID,String CustomerID,String packages,String day,String km,String Driversalary,String TotalAmount)
    {
       this.BookingID=BookingID;
       this.DriverID=DriverID;
       this.CustomerID=CustomerID;
       this.packages=packages;
       this.day=day;
       this.km=km;
       this.Driversalary=Driversalary;
       this.TotalAmount=TotalAmount;
       
    }
     paymenttable(String string, String string0, String string1, String String2) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
     public String BookingID()
    {
        return BookingID;
    }
      public String CustomerID()
    {
        return CustomerID;
    }
      public String DriverID()
    {
          return DriverID;
    }
       public String packages()
    {
          return packages;
    }
        public String day()
    {
          return day;
    }
         public String km()
    {
          return km;
    }
          public String Driversalary()
    {
          return Driversalary;
    }
           public String TotalAmount()
    {
          return TotalAmount;
    }
       
        
}
    

