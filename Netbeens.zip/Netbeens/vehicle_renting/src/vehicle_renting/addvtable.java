/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle_renting;

/**
 *
 * @author User
 */
public class addvtable {
    private String  VehicleID,VehicleNumber,VehicleName,CompanyName,Rateperkm,Rateperday,Stautas,Categories;
    String[] row;
     public addvtable(String VehicleID, String VehicleNumber,String VehicleName,String CompanyName,String Rateperkm,String Rateperday,String Stautas,String Categories)
    {
       this.VehicleID=VehicleID;
       this.VehicleNumber=VehicleNumber;
       this.VehicleName=VehicleName;
       this.CompanyName=CompanyName;
       this.Rateperkm=Rateperkm;
       this.Rateperday=Rateperday;
       this.Stautas=Stautas;
       this.Categories=Categories;
       
    }

    addvtable(String string, String string0, String string1, String string2, String string3, String string4, String string5, String string6, String string7) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    public String VehicleID()
    {
        return VehicleID;
    }
     public String VehicleNumber()
    {
        return VehicleNumber;
    }
      public String VehicleName()
    {
        return VehicleName;
    }
       public String CompanyName()
    {
        return CompanyName;
    }
        public String Rateperkm()
    {
        return Rateperkm;
    }
         public String Rateperday()
    {
        return Rateperday;
    }
        public String Stautas()
    {
        return Stautas;
            
    }
        public String Categories()
    {
        return Categories;
            
    }
              
    
}
