package vehicle_renting;

public class bookingtable {
     private String  BookingID,CustomerID,DriverID,VehicleID,TakeDate,RetuntDate,BookingTo,BookingFrom,PackageCatacary,km,days,booking_date;
     public bookingtable (String CustomerID,String BookingID,String DriverID,String VehicleID,String TakeDate,String RetuntDate,String BookingTo,String BookingFrom,String PackageCatacary,String km, String days,String booking_date)
    {
       this.BookingID=BookingID;
       this.CustomerID=CustomerID;
       this.DriverID=DriverID;
       this.VehicleID=VehicleID;
       this.BookingTo=BookingTo;
       this.BookingFrom=BookingFrom;
       this.TakeDate=TakeDate;
       this.RetuntDate=RetuntDate;
       this.PackageCatacary=PackageCatacary;
       this.km=km;
       this.days=days;
       this.booking_date=booking_date;
    }

    bookingtable(String string, String string0, String string1, String string2, String string3,String string4,String string5,String string6,String string7,String string8,String string9,String string10,String string11,String string12) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    public String BookingID()
     {
         return BookingID;
     }
     public String CustomerID()
    {
        return CustomerID;
    }
     public String DriverID()
     {
         return DriverID;
     }
     public String VehicleID()
     {
         return VehicleID;
     }
      public String BookingTo()
    {
        return BookingTo;
    }
       public String BookingFrom()
    {
        return BookingFrom;
    }
        public String TakeDate()
    {
        return TakeDate;
    }
        public String RetuntDate()
    {
        return RetuntDate;
    }
        public String PackageCatacary()
    {
        return PackageCatacary;
    }
        
        public String km()
    {
        return km;
    }
        public String days()
    {
        return days;
    }
        public String booking_date()
    {
        return booking_date;
    }
        
        

}
