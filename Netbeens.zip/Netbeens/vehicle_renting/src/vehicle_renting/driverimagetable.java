/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle_renting;

/**
 *
 * @author User
 */
public class driverimagetable {
    private String  driverid,name,nicnumber,licenceno,salary,licencecatocary,sex,Image;
    String[] row;
     public driverimagetable(String driverid,String name,String nicnumber,String licenceno,String salary,String licencecatocary,String sex,String Image)
    {
       this.driverid=driverid;
       this.name=name;
       this.nicnumber=nicnumber;
       this.licenceno=licenceno;
       this.salary=salary;
       this.licencecatocary=licencecatocary;
       this.sex=sex;
       this.Image=Image;
       
       
    }   
    driverimagetable(String string, String string0, String string1, String string2, String string3, String string4, String string5, String string6,String string7) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     public String driverid()
    {
        return driverid;
    }
      public String name()
    {
        return name;
    }
      public String nicnumber()
    {
        return nicnumber;
    }
      public String licenceno()
    {
        return licenceno;
    }
    public String salary()
    {
        return salary;
    }
      public String licencecatocary()
    {
        return licencecatocary;
    }
      public String sex()
    {
        return sex;
    }
      public String Image()
    {
        return Image;
    }
       

}
