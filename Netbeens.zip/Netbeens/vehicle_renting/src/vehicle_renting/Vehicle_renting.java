/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle_renting;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author User
 */
public class Vehicle_renting {

    
    public static void main(String[] args) {
        
       
        
        try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(Vehicle_renting.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(Vehicle_renting.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(Vehicle_renting.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(Vehicle_renting.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
       
        loginpanal a;
        a = new loginpanal();
        a.setVisible(true);
//        adminwelcome frame = new adminwelcome();
//        frame.setVisible(true);
//        frame.setSize(1321, 768);
    }
        }
    

