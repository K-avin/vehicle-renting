package vehicle_renting;


public class drivershowtable {
     private String  driver_id,Name,nic_number,licence_number,salary,licence_catocary,sex,status ;
    String[] row;
     public drivershowtable(String driver_id,String Name,String nic_number,String licence_number,String salary,String licence_catocary,String sex,String status)
    {
       this.driver_id=driver_id;
       this.Name=Name;
       this.nic_number=nic_number;
       this.licence_number=licence_number;
       this.salary=salary;
       this.licence_catocary=licence_catocary;
       this.sex=sex;
       this.status=status;
    }

    drivershowtable(String string, String string0, String string1, String string2, String string3) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
     public String driver_id()
    {
        return driver_id;
    }
      public String Name()
    {
        return Name;
    }
       public String nic_number()
    {
        return nic_number;
    }
        public String licence_number()
    {
        return licence_number;
    }
        public String salary()
    {
        return salary;
    }
        public String licence_catocary()
    {
          return licence_catocary;
    }
        public String sex()
    {
          return sex;
    }
         public String status()
    {
          return status;
    }
        
}
